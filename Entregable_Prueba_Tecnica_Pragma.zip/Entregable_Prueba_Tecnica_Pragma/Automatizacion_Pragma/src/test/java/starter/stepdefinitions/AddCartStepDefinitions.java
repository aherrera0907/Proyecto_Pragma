package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import starter.navigation.NavigateTo;
import starter.search.SearchBuy;
import starter.search.ValidarCompra;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;

public class AddCartStepDefinitions {

    @Given("{actor} usuario ingresa al portal de compras")
    public void ingresaPortal(Actor actor) {
        actor.wasAbleTo(NavigateTo.theSearchHomePage());
    }

    @When("{actor} busca sus productos y los compra")
    public void buscaYCompra(Actor actor) {
        actor.attemptsTo(
                SearchBuy.item()
        );
    }
    @Then("{actor} realiza el pago exitoso")
    public void veElPago(Actor actor) {
        actor.should(seeThat(ValidarCompra.esVisible()));
    }

}
