package starter.navigation;

import net.serenitybdd.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("https://www.demoblaze.com/")
public class BlazeHomePage extends PageObject {
}
