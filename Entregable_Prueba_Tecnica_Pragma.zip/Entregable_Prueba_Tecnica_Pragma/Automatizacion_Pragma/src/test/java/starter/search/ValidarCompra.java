package starter.search;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.waits.WaitUntil;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isEnabled;
import static starter.search.SearchForm.BTN_VALIDATE;

public class ValidarCompra implements Question<Boolean> {


    @Override
    public Boolean answeredBy(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(BTN_VALIDATE, isEnabled()).forNoMoreThan(30).seconds()

);
        return BTN_VALIDATE.resolveFor(actor).isVisible();
    }

    public static ValidarCompra esVisible() {
        return new ValidarCompra();
    }
}
