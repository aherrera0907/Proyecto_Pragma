package starter.search;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.thucydides.core.webdriver.WebDriverFacade;
import starter.utilities.Esperar;

import static net.serenitybdd.core.Serenity.getDriver;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isEnabled;
import static net.thucydides.core.webdriver.ThucydidesWebDriverSupport.getProxiedDriver;
import static starter.search.SearchForm.*;

public class SearchBuy implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                WaitUntil.the(BTN_ITEM, isEnabled()).forNoMoreThan(30).seconds(),
                Click.on(BTN_ITEM),
                WaitUntil.the(BTN_ADD_TO_CART, isEnabled()).forNoMoreThan(30).seconds(),
                Click.on(BTN_ADD_TO_CART),
                Esperar.unTiempo(5000)
        );

        // CIERRA VENTANA EMERGENTE
        //CARGA UNA INSTANCIA DEL DRIVER DE SELENIUM PARA USAR CODIGO NATIVO DE EL
        ((WebDriverFacade) getDriver()).getProxiedDriver().switchTo().alert().accept();

        actor.attemptsTo(
                WaitUntil.the(BTN_CART, isEnabled()).forNoMoreThan(30).seconds(),
                Click.on(BTN_CART),
                Esperar.unTiempo(5000),

                WaitUntil.the(BTN_PLACE_ORDER, isEnabled()).forNoMoreThan(30).seconds(),
                Click.on(BTN_PLACE_ORDER),
                Esperar.unTiempo(5000),

                WaitUntil.the(FIELD_NAME, isEnabled()).forNoMoreThan(30).seconds(),
                Enter.theValue("Anderson").into(FIELD_NAME),

                WaitUntil.the(CREDIT_CARD, isEnabled()).forNoMoreThan(30).seconds(),
                Enter.theValue("123").into(CREDIT_CARD),

                WaitUntil.the(BTN_PURCHASE, isEnabled()).forNoMoreThan(30).seconds(),
                Click.on(BTN_PURCHASE)

        );
    }

    public static SearchBuy item() {
        return new SearchBuy(
        );

    }
}
