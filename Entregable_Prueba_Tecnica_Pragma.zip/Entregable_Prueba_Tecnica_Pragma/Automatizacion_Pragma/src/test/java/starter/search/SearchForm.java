package starter.search;

import net.serenitybdd.screenplay.targets.Target;

class SearchForm {

    static Target BTN_ITEM = Target.the("item a agregar").locatedBy("//a[normalize-space()='Samsung galaxy s6']");
    static Target BTN_ADD_TO_CART = Target.the("item a agregar").locatedBy("//a[normalize-space()='Add to cart']");
    static Target  BTN_CART = Target.the("item a agregar").locatedBy("//a[@id='cartur']");
   static Target BTN_VALIDATE = Target.the("item a agregar").locatedBy("//button[normalize-space()='OK']");
    static Target BTN_PLACE_ORDER = Target.the("item a agregar").locatedBy("//button[normalize-space()='Place Order']");
    static Target FIELD_NAME = Target.the("item a agregar").locatedBy("//input[@id='name']");
    static Target CREDIT_CARD = Target.the("item a agregar").locatedBy("//input[@id='card']");
    static Target BTN_PURCHASE = Target.the("item a agregar").locatedBy("//button[normalize-space()='Purchase']");


}
