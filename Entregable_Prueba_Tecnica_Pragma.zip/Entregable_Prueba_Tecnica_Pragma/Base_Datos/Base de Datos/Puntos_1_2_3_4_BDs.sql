/*1
Consultar el supermercado que tenga más cantidad de productos con el tipo
“CARNICOS” que han vendido hasta la fecha 31 de diciembre del 2013 retornando el
nombre del supermercado, la cantidad, la descripción del tipo de supermercado y la
fecha de venta.(8 minutos)*/
/*ingreso: supermercado con mas cantidad de productos con el tipo 'carnicos' hasta fecha 31 dic 2023
salida: nombre del supermercado - la cantidad  la descripción del tipo de supermercado - fecha venta*/
select * from inventario;
select * from producto;
select * from factura;
select * from supermercado;
select * from tipo_producto;

select  s.nombre_supermercado as NOM_SUPERMERCADO, i.CANTIDAD as cantidad, 
t.DESCRIPCION_tipo as DESCRIPCION_tipo, f.FECHA_VENTE as FECHA_VENTE 
from producto p 
inner join  tipo_producto t on    p.id_tipo_producto = t.id_tipo_producto
inner join  inventario i on    p.id_producto = i.id_producto
inner join  factura  f on  p.id_producto =f.id_producto
inner join  vendedor  v on v.id_vendedor= f.id_vendedor
inner join  supermercado  s on s.id_supermercado=v.id_supermercado
where t.DESCRIPCION_tipo = 'Carnicos' ;
and f.FECHA_VENTE < 2023-12-31/ 

/*select s.nombre_supermercado as NOM_SUPERMERCADO, i.CANTIDAD as cantidad, 
t.DESCRIPCION_tipo as DESCRIPCION_tipo, f.FECHA_VENTE as FECHA_VENTE
from inventario i, producto p, factura f, supermercado s , tipo_producto t 
where (s.id_supermercado = s.id_supermercado) 
and t.DESCRIPCION_tipo = 'Carnicos' ;
/*and f.FECHA_VENTE < 2023-12-31 */

/*2
Seleccionar los clientes que compran en el SUPERMERCADO “Exito” cuya compra supera
los $150.000 mil peso e imprimir todos los datos del cliente más el nombre del
supermercado y el valor de venta, y ordenarlos descendentemente.(10 minutos)*/

select * from cliente;
select * from supermercado;
select * from factura;
select * from vendedor;

select c.id_cliente as ID_CLIENTE, c.nombre_cliente as NOMBRE_CLIENTE, c.APELLIDO_CLIENTE as APELLIDO_CLIENTE, c.CEDULA_CLIENTE as CEDULA_CLIENTE, c.TELEFONO_CLIENTE as TELEFONO_CLIENTE, c.DIRECCION as DIRECCION, s.nombre_supermercado as NOM_SUPERMERCADO, f.valor_venta as VALOR_VENTA from cliente c, factura f, vendedor v, supermercado s 
where (c.id_cliente = f.id_cliente) and (f.id_vendedor = v.id_vendedor) and (v.id_supermercado = s.id_supermercado) and s.nombre_supermercado = 'Exito' and f.valor_venta > 150000 order by f.valor_venta desc;

/*3
Construir la consulta que permita conocer las ventas totales de cada vendedor en cada
SUPERMERCADO, retornando el nombre del vendedor, SUPERMERCADO y valor total de
ventas por cada vendedor ordenado descendentemente por valor.(8 minutos)*/
/*ingreso: venta total de cada vendedor en cada supermercado
salida: nombre del vendedor - supermercado - valor_venta desc*/
select * from cliente;
select * from factura;
select * from vendedor;
select * from supermercado;

select v.nombre_vendedor as NOMBRE_vendedor, s.nombre_supermercado as NOM_SUPERMERCADO, f.valor_venta as VALOR_VENTA from cliente c, factura f, vendedor v, supermercado s where (c.id_cliente = f.id_cliente) and (f.id_vendedor = v.id_vendedor) and (v.id_supermercado = s.id_supermercado) and s.nombre_supermercado in ('Exito','Sumerca huila','Carula','Jumbo','Colsubsidio') order by f.valor_venta desc;

/*select v.nombre_vendedor as NOMBRE_vendedor, s.nombre_supermercado as NOM_SUPERMERCADO, SUM(f.valor_venta)
from producto p inner join factura f on  p.id_producto =f.id_producto
inner join  vendedor  v on v.id_vendedor= f.id_vendedor
inner join  supermercado  s on s.id_supermercado=v.id_supermercado
group by NOM_SUPERMERCADO*/

/*4
Consultar las facturas cuyo valor es superior a $100.000 pesos y el código del vendedor
sea el 3, retornando el número de la factura, el valor de la factura y el nombre del
vendedor.(10 minutos)*/
select * from factura;
select * from vendedor;
/*factura y vendedor*/
select f.numero_factura as NRO_FACTURA, f.valor_venta as VALOR_FACTURA, v.nombre_vendedor as NOMBRE_VENDEDOR 
from factura f, vendedor v 
where (f.id_vendedor = v.id_vendedor) 
and (f.valor_venta > 100000) 
and (f.id_vendedor = '3');